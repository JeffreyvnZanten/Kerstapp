'use client'

import { useSession, signIn, signOut } from 'next-auth/react'
import ChristmasCountdown from './ChristmasCountdown'

export default function Home() {
  const { data: session, status } = useSession()

  if (status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
      </div>
    )
  }

  return (
    <main>
      <div className="bg-[url('/xmas1.webp')] bg-cover bg-center bg-no-repeat min-h-screen w-full fixed inset-0">
        <ChristmasCountdown />
        
        <div className="flex flex-col items-center mt-8 space-y-4">
          {session ? (
            <>
              <div className="text-white bg-black bg-opacity-50 px-4 py-2 rounded">
                Welcome, {session.user?.email}
              </div>
              <button 
                onClick={() => signOut()}
                className="bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600 transition-colors"
              >
                Sign out
              </button>
            </>
          ) : (
            <>
              <div className="text-white bg-black bg-opacity-50 px-4 py-2 rounded">
                Sign in to join the Christmas countdown!
              </div>
              <div className="space-y-2">
                <button 
                  onClick={() => signIn('google')}
                  className="w-full bg-white text-gray-800 px-6 py-2 rounded hover:bg-gray-100 transition-colors flex items-center justify-center gap-2"
                >
                  <img src="/google.svg" alt="Google" className="w-5 h-5" />
                  Sign in with Google
                </button>
                <button 
                  onClick={() => signIn('facebook')}
                  className="w-full bg-[#1877F2] text-white px-6 py-2 rounded hover:bg-[#1864F2] transition-colors flex items-center justify-center gap-2"
                >
                  <img src="/facebook.svg" alt="Facebook" className="w-5 h-5" />
                  Sign in with Facebook
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </main>
  )
}